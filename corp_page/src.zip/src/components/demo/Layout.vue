<template>
<LayoutVer>
  <div slot="top">
    <div class="page">
      <div class="page-bar"> 
        <div class="page-title">
          布局组件
        </div>
      </div>
    </div>
  </div> 
  <LayoutHor>
    <div slot="left" class="demolayout-block" style="height:100%;width:200px;">
       <LayoutVer>
          <div slot="top" class="demolayout-block">
            组织架构(上)
          </div> 
          <div>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
            center<br/>
          </div>
          <div slot="bottom" class="demolayout-block">
            未分配部门(下)
          </div>
      </LayoutVer> 
    </div> 
    <LayoutVer>
        <div slot="top" class="demolayout-block">
          条件框
        </div>
        <div> 
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
          列表查询<br/>
        </div>
        <div slot="bottom" class="demolayout-block">
          分页条 第1页
        </div>
    </LayoutVer>  
  </LayoutHor>
</LayoutVer>
</template>

<script>

import LayoutVer from '@/components/layout/LayoutVer';
import LayoutHor from '@/components/layout/LayoutHor';

export default {
  components: {
    LayoutVer,
    LayoutHor
  },
  data() { 
    var that = this;
    return {
       
    }
  },
  mounted:function(){ 
     
  },
  computed:{
     
  },
  methods:{
    load: function() { 
         
    }
  }
}

</script>

<style type="text/css">
  .demolayout-block{height: 30px;line-height: 30px; background-color: white;border: solid 1px #ccc;}
</style>