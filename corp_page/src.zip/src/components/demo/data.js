export default {
	tree:{
		"code":0,
		"message":"ok",
		"data":[
			{"powerId":1,"powerKey":"","powerType":"2","powerIcon":"","powerCaption":"工作台","parentId":0},
			{"powerId":2,"powerKey":"","powerType":"","powerIcon":"","powerCaption":"客户管理","parentId":0},
			{"powerId":3,"powerKey":"","powerType":"","powerIcon":"","powerCaption":"我的客户","parentId":2},
			{"powerId":4,"powerKey":"","powerType":"","powerIcon":"","powerCaption":"客户转移","parentId":2},
			{"powerId":5,"powerKey":"","powerType":"","powerIcon":"","powerCaption":"产品管理","parentId":0},
			{"powerId":6,"powerKey":"","powerType":"","powerIcon":"","powerCaption":"备选库","parentId":5}
		]
	} 
}