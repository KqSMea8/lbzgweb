import SelectMaterial from './SelectMaterial.vue';
export default SelectMaterial;