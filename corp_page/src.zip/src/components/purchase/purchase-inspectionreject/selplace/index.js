import SelectPlace from './SelectPlace.vue';
export default SelectPlace;