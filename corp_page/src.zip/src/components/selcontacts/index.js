import SelectDeptPerson from './SelectDeptPerson.vue';
export default SelectDeptPerson;