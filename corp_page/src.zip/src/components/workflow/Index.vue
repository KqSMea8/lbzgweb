<template>
  <div>
     <h1>首页</h1>
  </div>
</template>

<script>

</script>

<style type="text/css" scoped>
   
</style>
<style>
   
</style>
